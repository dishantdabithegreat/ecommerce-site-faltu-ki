
(() => {
  const API = (window.SHOP_API_URL || "http://127.0.0.1:5000") + "/api";
  let products = [];
  let me = null;

  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];

  function toast(msg) {
    let el = document.getElementById("backend-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "backend-toast";
      Object.assign(el.style, {
        position:"fixed", right:"20px", bottom:"20px", zIndex:"99999",
        background:"#222", color:"#fff", padding:"12px 18px",
        borderRadius:"8px", fontFamily:"Arial,sans-serif", maxWidth:"320px"
      });
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.display = "block";
    clearTimeout(el._t);
    el._t = setTimeout(() => el.style.display = "none", 2500);
  }

  async function api(path, options={}) {
    const opts = {...options, credentials:"include", headers:{...(options.headers||{})}};
    if (opts.body && typeof opts.body !== "string") {
      opts.headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(opts.body);
    }
    const res = await fetch(API + path, opts);
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok) throw new Error(data.error || "Request failed");
    return data;
  }

  const normalize = s => (s || "").trim().toLowerCase().replace(/\s+/g, " ");

  async function loadProducts() {
    products = await api("/products?limit=200");
    wireProductButtons();
  }

  function productForElement(el) {
    const card = el.closest(".showcase");
    if (!card) return null;
    const title = $(".showcase-title", card)?.textContent?.trim();
    if (!title) return null;
    const n = normalize(title);
    return products.find(p => normalize(p.name) === n) ||
           products.find(p => normalize(p.name).includes(n) || n.includes(normalize(p.name)));
  }

  function wireProductButtons() {
    $$(".product-main .add-cart-btn, .product-featured .add-cart-btn").forEach(btn => {
      if (btn.dataset.backendWired) return;
      btn.dataset.backendWired = "1";
      btn.addEventListener("click", async e => {
        e.preventDefault();
        const p = productForElement(btn);
        if (!p) return toast("Ye product backend catalog me nahi hai.");
        try {
          await api("/cart", {method:"POST", body:{product_id:p.id, quantity:1}});
          toast(`${p.name} cart me add ho gaya.`);
          await refreshCounts();
        } catch (err) {
          if (err.message === "Login required") {
            openAuth("login");
          } else toast(err.message);
        }
      });
    });

    $$(".product-main .action-btn, .product-main .action-btn ion-icon").forEach(btn => {
      const b = btn.closest(".action-btn");
      if (!b || b.dataset.backendWishlistWired) return;
      const icon = $("ion-icon", b);
      if (!icon || !icon.getAttribute("name")?.includes("heart")) return;
      b.dataset.backendWishlistWired = "1";
      b.addEventListener("click", async e => {
        e.preventDefault();
        const p = productForElement(b);
        if (!p) return;
        try {
          await api(`/wishlist/${p.id}`, {method:"POST"});
          toast("Wishlist update ho gayi.");
          await refreshCounts();
        } catch (err) {
          if (err.message === "Login required") openAuth("login");
          else toast(err.message);
        }
      });
    });
  }

  async function refreshCounts() {
    if (!me) {
      $$(".header-user-actions .count").forEach((x,i) => { if (i<2) x.textContent="0"; });
      return;
    }
    try {
      const [cart, wish] = await Promise.all([api("/cart"), api("/wishlist")]);
      const counts = $$(".header-user-actions .count");
      // Header order in this template: wishlist then cart.
      if (counts[0]) counts[0].textContent = wish.items?.length || 0;
      if (counts[1]) counts[1].textContent = cart.items?.reduce((n,x)=>n+x.quantity,0) || 0;
    } catch {}
  }

  function openAuth(mode="login") {
    let modal = $("#backend-auth-modal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "backend-auth-modal";
      Object.assign(modal.style, {
        position:"fixed", inset:"0", background:"rgba(0,0,0,.55)", zIndex:"100000",
        display:"grid", placeItems:"center", padding:"20px"
      });
      modal.innerHTML = `
        <div style="background:#fff;padding:25px;border-radius:12px;width:min(420px,100%);font-family:Arial">
          <button id="auth-close" style="float:right;border:0;background:none;font-size:22px">×</button>
          <h2 id="auth-title">Login</h2>
          <form id="auth-form">
            <input id="auth-name" placeholder="Name" style="display:none;width:100%;padding:12px;margin:7px 0">
            <input id="auth-email" type="email" required placeholder="Email" style="width:100%;padding:12px;margin:7px 0">
            <input id="auth-password" type="password" required placeholder="Password (6+ chars)" style="width:100%;padding:12px;margin:7px 0">
            <button style="width:100%;padding:12px;margin-top:10px;cursor:pointer">Continue</button>
          </form>
          <p id="auth-switch" style="cursor:pointer;text-align:center">Create account</p>
        </div>`;
      document.body.appendChild(modal);
      $("#auth-close", modal).onclick = () => modal.remove();
      $("#auth-switch", modal).onclick = () => openAuth($("#auth-title").textContent === "Login" ? "register" : "login");
      $("#auth-form", modal).onsubmit = async e => {
        e.preventDefault();
        const isReg = $("#auth-title").textContent === "Register";
        try {
          me = (await api(isReg ? "/auth/register" : "/auth/login", {
            method:"POST",
            body: {
              ...(isReg ? {name:$("#auth-name").value} : {}),
              email:$("#auth-email").value,
              password:$("#auth-password").value
            }
          })).user;
          modal.remove();
          toast(`Welcome ${me.name}`);
          await refreshCounts();
        } catch (err) { toast(err.message); }
      };
    }
    $("#auth-title", modal).textContent = mode === "register" ? "Register" : "Login";
    $("#auth-name", modal).style.display = mode === "register" ? "block" : "none";
    $("#auth-switch", modal).textContent = mode === "register" ? "Already have an account? Login" : "Create account";
    modal.style.display = "grid";
  }

  async function showCart() {
    if (!me) return openAuth("login");
    try {
      const data = await api("/cart");
      let text = data.items?.length ? data.items.map(x => `${x.name} × ${x.quantity} = $${(x.price*x.quantity).toFixed(2)}`).join("\n") : "Cart empty";
      text += `\n\nTotal: $${Number(data.total||0).toFixed(2)}`;
      alert(text);
    } catch (e) { toast(e.message); }
  }

  async function search() {
    const input = $(".search-field");
    const q = input?.value?.trim();
    if (!q) return loadProducts();
    try {
      const found = await api("/products?q=" + encodeURIComponent(q));
      const titles = new Set(found.map(p => normalize(p.name)));
      $$(".product-main .showcase").forEach(card => {
        const title = normalize($(".showcase-title", card)?.textContent);
        card.style.display = [...titles].some(t => t===title || t.includes(title) || title.includes(t)) ? "" : "none";
      });
      toast(`${found.length} product(s) found`);
    } catch (e) { toast(e.message); }
  }

  async function newsletterSubmit(form) {
    const email = $("input[name=email]", form)?.value;
    try {
      await api("/newsletter", {method:"POST", body:{email}});
      toast("Newsletter subscribed.");
      form.reset();
    } catch(e) { toast(e.message); }
  }

  async function boot() {
    try { me = (await api("/auth/me")).user; } catch {}
    try { await loadProducts(); } catch (e) { toast("Backend start nahi hai."); }
    await refreshCounts();

    $(".search-btn")?.addEventListener("click", e => { e.preventDefault(); search(); });
    $(".search-field")?.addEventListener("keydown", e => { if (e.key === "Enter") search(); });

    $$('form input[name="email"]').forEach(input => {
      const form = input.closest("form");
      if (form && !form.dataset.backendNewsletter) {
        form.dataset.backendNewsletter = "1";
        form.addEventListener("submit", e => { e.preventDefault(); newsletterSubmit(form); });
      }
    });

    // First header action = login/account; second = wishlist; third = cart in this template.
    const actions = $$(".header-user-actions .action-btn");
    if (actions[0]) actions[0].addEventListener("click", () => me ? toast(`Logged in as ${me.name}`) : openAuth("login"));
    if (actions[1]) actions[1].addEventListener("click", async () => {
      if (!me) return openAuth("login");
      try { const d=await api("/wishlist"); alert(d.items?.map(x=>x.name).join("\n") || "Wishlist empty"); } catch(e){toast(e.message);}
    });
    if (actions[2]) actions[2].addEventListener("click", showCart);
  }

  document.addEventListener("DOMContentLoaded", boot);
})();
