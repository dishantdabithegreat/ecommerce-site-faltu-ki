# Anon eCommerce - Frontend + Backend Connected

This package connects the uploaded Anon eCommerce frontend to the Flask + SQLite backend.

## Folder structure
- `backend/app.py` - Flask API + SQLite database
- `backend/requirements.txt` - Python dependencies
- `backend/make_admin.py` - create/promote an admin user
- `frontend/index.html` - your uploaded frontend
- `frontend/backend.js` - frontend-to-backend connection

## Run on Windows

Open Command Prompt in the `backend` folder:

```bat
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open:

`http://127.0.0.1:5000`

## Important
Your uploaded HTML references an `assets` folder (`assets/css`, `assets/js`, `assets/images`), but that folder was not included with the HTML upload. Put your original `assets` folder beside `frontend/index.html`:

`frontend/assets/...`

The backend connection itself is included.

## Connected features
- Product API / search
- Register and login
- Session authentication
- Add to cart
- Cart quantity and total
- Wishlist
- Newsletter subscription
- Orders API
- Admin order/product APIs

The existing design is kept; `backend.js` adds the database/API functionality.
