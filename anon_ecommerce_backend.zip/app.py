import os
import sqlite3
from functools import wraps
from flask import Flask, request, jsonify, session
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "store.db")

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
CORS(app, supports_credentials=True)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        price REAL NOT NULL,
        old_price REAL,
        image TEXT,
        stock INTEGER NOT NULL DEFAULT 50,
        description TEXT DEFAULT '',
        rating REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS cart (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 1,
        UNIQUE(user_id, product_id),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS wishlist (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        UNIQUE(user_id, product_id),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        total REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        pincode TEXT NOT NULL,
        payment_method TEXT NOT NULL DEFAULT 'cod',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL,
        FOREIGN KEY(order_id) REFERENCES orders(id),
        FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS subscribers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL UNIQUE,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    """)
    conn.commit()
    conn.close()

def seed_products():
    # Seed only if the products table is empty.
    conn = db()
    count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if count == 0:
        seed = PRODUCT_SEED
        conn.executemany(
            """INSERT INTO products
               (name, category, price, old_price, image, stock, description, rating)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            seed
        )
        conn.commit()
    conn.close()

def row_product(row):
    return dict(row)

def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    conn = db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    conn.close()
    return user

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            return jsonify({"error": "Login required"}), 401
        return fn(*args, **kwargs)
    return wrapper

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "service": "Anon eCommerce backend"})

@app.get("/api/products")
def products_api():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip().lower()
    limit = min(max(int(request.args.get("limit", 100)), 1), 200)
    conn = db()
    sql = "SELECT * FROM products WHERE 1=1"
    params = []
    if q:
        sql += " AND (name LIKE ? OR category LIKE ? OR description LIKE ?)"
        like = f"%{q}%"
        params += [like, like, like]
    if category:
        sql += " AND LOWER(category)=?"
        params.append(category)
    sql += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return jsonify([row_product(r) for r in rows])

@app.get("/api/products/<int:product_id>")
def product_detail(product_id):
    conn = db()
    row = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    conn.close()
    if not row:
        return jsonify({"error": "Product not found"}), 404
    return jsonify(row_product(row))

@app.post("/api/auth/register")
def register():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    if not name or not email or len(password) < 6:
        return jsonify({"error": "Name, valid email and password (6+ chars) are required"}), 400

    conn = db()
    try:
        cur = conn.execute(
            "INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
            (name, email, generate_password_hash(password))
        )
        conn.commit()
        session["user_id"] = cur.lastrowid
        return jsonify({"message": "Registered successfully", "user": {
            "id": cur.lastrowid, "name": name, "email": email
        }}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Email already registered"}), 409
    finally:
        conn.close()

@app.post("/api/auth/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))
    conn = db()
    user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    conn.close()
    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "Invalid email or password"}), 401
    session["user_id"] = user["id"]
    return jsonify({"message": "Login successful", "user": {
        "id": user["id"], "name": user["name"], "email": user["email"],
        "is_admin": bool(user["is_admin"])
    }})

@app.post("/api/auth/logout")
def logout():
    session.clear()
    return jsonify({"message": "Logged out"})

@app.get("/api/auth/me")
def me():
    user = current_user()
    if not user:
        return jsonify({"user": None})
    return jsonify({"user": {
        "id": user["id"], "name": user["name"], "email": user["email"],
        "is_admin": bool(user["is_admin"])
    }})

@app.post("/api/newsletter")
def newsletter():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email", "")).strip().lower()
    if "@" not in email:
        return jsonify({"error": "Valid email required"}), 400
    conn = db()
    try:
        conn.execute("INSERT INTO subscribers(email) VALUES(?)", (email,))
        conn.commit()
        return jsonify({"message": "Subscribed successfully"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"message": "Already subscribed"}), 200
    finally:
        conn.close()

def get_cart_rows(user_id):
    conn = db()
    rows = conn.execute("""
        SELECT c.product_id, c.quantity, p.name, p.category, p.price, p.image, p.stock
        FROM cart c JOIN products p ON p.id=c.product_id
        WHERE c.user_id=? ORDER BY c.id DESC
    """, (user_id,)).fetchall()
    conn.close()
    items = [dict(r) for r in rows]
    total = sum(x["price"] * x["quantity"] for x in items)
    return {"items": items, "total": round(total, 2)}

@app.get("/api/cart")
@login_required
def get_cart():
    return jsonify(get_cart_rows(session["user_id"]))

@app.post("/api/cart")
@login_required
def add_cart():
    data = request.get_json(silent=True) or {}
    pid = int(data.get("product_id", 0))
    qty = max(int(data.get("quantity", 1)), 1)
    conn = db()
    p = conn.execute("SELECT stock FROM products WHERE id=?", (pid,)).fetchone()
    if not p:
        conn.close()
        return jsonify({"error": "Product not found"}), 404
    if qty > p["stock"]:
        conn.close()
        return jsonify({"error": "Not enough stock"}), 400
    conn.execute("""
        INSERT INTO cart(user_id,product_id,quantity) VALUES(?,?,?)
        ON CONFLICT(user_id,product_id)
        DO UPDATE SET quantity=quantity+excluded.quantity
    """, (session["user_id"], pid, qty))
    conn.commit()
    conn.close()
    return jsonify(get_cart_rows(session["user_id"]))

@app.patch("/api/cart/<int:product_id>")
@login_required
def update_cart(product_id):
    data = request.get_json(silent=True) or {}
    qty = int(data.get("quantity", 1))
    conn = db()
    if qty <= 0:
        conn.execute("DELETE FROM cart WHERE user_id=? AND product_id=?", (session["user_id"], product_id))
    else:
        stock = conn.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()
        if not stock or qty > stock["stock"]:
            conn.close()
            return jsonify({"error": "Invalid quantity or insufficient stock"}), 400
        conn.execute("UPDATE cart SET quantity=? WHERE user_id=? AND product_id=?",
                     (qty, session["user_id"], product_id))
    conn.commit()
    conn.close()
    return jsonify(get_cart_rows(session["user_id"]))

@app.delete("/api/cart/<int:product_id>")
@login_required
def delete_cart(product_id):
    conn = db()
    conn.execute("DELETE FROM cart WHERE user_id=? AND product_id=?", (session["user_id"], product_id))
    conn.commit()
    conn.close()
    return jsonify(get_cart_rows(session["user_id"]))

@app.get("/api/wishlist")
@login_required
def get_wishlist():
    conn = db()
    rows = conn.execute("""
        SELECT p.* FROM wishlist w JOIN products p ON p.id=w.product_id
        WHERE w.user_id=? ORDER BY w.id DESC
    """, (session["user_id"],)).fetchall()
    conn.close()
    return jsonify([row_product(r) for r in rows])

@app.post("/api/wishlist/<int:product_id>")
@login_required
def toggle_wishlist(product_id):
    conn = db()
    exists = conn.execute(
        "SELECT id FROM wishlist WHERE user_id=? AND product_id=?",
        (session["user_id"], product_id)
    ).fetchone()
    if exists:
        conn.execute("DELETE FROM wishlist WHERE id=?", (exists["id"],))
        action = "removed"
    else:
        p = conn.execute("SELECT id FROM products WHERE id=?", (product_id,)).fetchone()
        if not p:
            conn.close()
            return jsonify({"error": "Product not found"}), 404
        conn.execute("INSERT INTO wishlist(user_id,product_id) VALUES(?,?)",
                     (session["user_id"], product_id))
        action = "added"
    conn.commit()
    conn.close()
    return jsonify({"action": action})

@app.post("/api/orders")
@login_required
def create_order():
    data = request.get_json(silent=True) or {}
    required = ["name", "phone", "address", "city", "pincode"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return jsonify({"error": "Name, phone, address, city and pincode are required"}), 400

    cart = get_cart_rows(session["user_id"])
    if not cart["items"]:
        return jsonify({"error": "Cart is empty"}), 400

    payment_method = str(data.get("payment_method", "cod")).lower()
    if payment_method not in ("cod", "online"):
        return jsonify({"error": "Invalid payment method"}), 400

    conn = db()
    try:
        # Recheck stock inside the transaction.
        for item in cart["items"]:
            p = conn.execute("SELECT stock FROM products WHERE id=?", (item["product_id"],)).fetchone()
            if not p or item["quantity"] > p["stock"]:
                raise ValueError(f"Insufficient stock for {item['name']}")

        cur = conn.execute("""
            INSERT INTO orders(user_id,total,name,phone,address,city,pincode,payment_method)
            VALUES(?,?,?,?,?,?,?,?)
        """, (session["user_id"], cart["total"], data["name"].strip(), data["phone"].strip(),
              data["address"].strip(), data["city"].strip(), data["pincode"].strip(), payment_method))
        order_id = cur.lastrowid

        for item in cart["items"]:
            conn.execute("""
                INSERT INTO order_items(order_id,product_id,quantity,price)
                VALUES(?,?,?,?)
            """, (order_id, item["product_id"], item["quantity"], item["price"]))
            conn.execute("UPDATE products SET stock=stock-? WHERE id=?",
                         (item["quantity"], item["product_id"]))

        conn.execute("DELETE FROM cart WHERE user_id=?", (session["user_id"],))
        conn.commit()
        return jsonify({"message": "Order created", "order_id": order_id, "total": cart["total"]}), 201
    except ValueError as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 400
    finally:
        conn.close()

@app.get("/api/orders")
@login_required
def my_orders():
    conn = db()
    orders = conn.execute(
        "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC", (session["user_id"],)
    ).fetchall()
    result = []
    for o in orders:
        items = conn.execute("""
            SELECT oi.*, p.name, p.image FROM order_items oi
            JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?
        """, (o["id"],)).fetchall()
        item = dict(o)
        item["items"] = [dict(x) for x in items]
        result.append(item)
    conn.close()
    return jsonify(result)

# ---------- Admin APIs ----------
def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()
        if not user or not user["is_admin"]:
            return jsonify({"error": "Admin access required"}), 403
        return fn(*args, **kwargs)
    return wrapper

@app.get("/api/admin/orders")
@admin_required
def admin_orders():
    conn = db()
    rows = conn.execute("""
        SELECT o.*, u.email FROM orders o JOIN users u ON u.id=o.user_id
        ORDER BY o.id DESC
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.patch("/api/admin/orders/<int:order_id>")
@admin_required
def admin_update_order(order_id):
    data = request.get_json(silent=True) or {}
    status = str(data.get("status", "")).lower()
    allowed = {"pending", "confirmed", "shipped", "delivered", "cancelled"}
    if status not in allowed:
        return jsonify({"error": "Invalid status"}), 400
    conn = db()
    cur = conn.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        return jsonify({"error": "Order not found"}), 404
    return jsonify({"message": "Order updated"})

@app.post("/api/admin/products")
@admin_required
def admin_add_product():
    data = request.get_json(silent=True) or {}
    try:
        name = str(data["name"]).strip()
        category = str(data["category"]).strip().lower()
        price = float(data["price"])
        old_price = float(data["old_price"]) if data.get("old_price") is not None else None
        stock = int(data.get("stock", 50))
    except (KeyError, ValueError):
        return jsonify({"error": "name, category and numeric price are required"}), 400
    conn = db()
    cur = conn.execute("""
        INSERT INTO products(name,category,price,old_price,image,stock,description,rating)
        VALUES(?,?,?,?,?,?,?,?)
    """, (name, category, price, old_price, data.get("image",""), stock,
          data.get("description",""), float(data.get("rating",0))))
    conn.commit()
    pid = cur.lastrowid
    conn.close()
    return jsonify({"message": "Product added", "id": pid}), 201

@app.patch("/api/admin/products/<int:product_id>")
@admin_required
def admin_update_product(product_id):
    data = request.get_json(silent=True) or {}
    fields = []
    values = []
    allowed = ["name", "category", "price", "old_price", "image", "stock", "description", "rating"]
    for key in allowed:
        if key in data:
            fields.append(f"{key}=?")
            values.append(data[key])
    if not fields:
        return jsonify({"error": "Nothing to update"}), 400
    values.append(product_id)
    conn = db()
    cur = conn.execute(f"UPDATE products SET {', '.join(fields)} WHERE id=?", values)
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        return jsonify({"error": "Product not found"}), 404
    return jsonify({"message": "Product updated"})

@app.delete("/api/admin/products/<int:product_id>")
@admin_required
def admin_delete_product(product_id):
    conn = db()
    cur = conn.execute("DELETE FROM products WHERE id=?", (product_id,))
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        return jsonify({"error": "Product not found"}), 404
    return jsonify({"message": "Product deleted"})

# Inserted by generator:
PRODUCT_SEED = [('Mens Winter Leathers Jackets', 'jacket', 48.0, 55.2, './assets/images/products/jacket-3.jpg', 50, 'Mens Winter Leathers Jackets from the Anon eCommerce catalog.', 4.0), ('Pure Garment Dyed Cotton Shirt', 'shirt', 45.0, 51.75, './assets/images/products/shirt-1.jpg', 50, 'Pure Garment Dyed Cotton Shirt from the Anon eCommerce catalog.', 4.0), ('MEN Yarn Fleece Full-Zip Jacket', 'jacket', 58.0, 66.7, './assets/images/products/jacket-5.jpg', 50, 'MEN Yarn Fleece Full-Zip Jacket from the Anon eCommerce catalog.', 4.0), ('Black Floral Wrap Midi Skirt', 'skirt', 25.0, 28.75, './assets/images/products/clothes-3.jpg', 50, 'Black Floral Wrap Midi Skirt from the Anon eCommerce catalog.', 4.0), ("Casual Men's Brown shoes", 'casual', 99.0, 113.85, './assets/images/products/shoe-2.jpg', 50, "Casual Men's Brown shoes from the Anon eCommerce catalog.", 4.0), ('Pocket Watch Leather Pouch', 'watches', 150.0, 172.5, './assets/images/products/watch-3.jpg', 50, 'Pocket Watch Leather Pouch from the Anon eCommerce catalog.', 4.0), ('Smart watche Vital Plus', 'watches', 100.0, 115.0, './assets/images/products/watch-1.jpg', 50, 'Smart watche Vital Plus from the Anon eCommerce catalog.', 4.0), ('Womens Party Wear Shoes', 'party wear', 25.0, 28.75, './assets/images/products/party-wear-1.jpg', 50, 'Womens Party Wear Shoes from the Anon eCommerce catalog.', 4.0), ('Mens Winter Leathers Jackets', 'jacket', 32.0, 36.8, './assets/images/products/jacket-1.jpg', 50, 'Mens Winter Leathers Jackets from the Anon eCommerce catalog.', 4.0), ('Trekking & Running Shoes - black', 'sports', 58.0, 66.7, './assets/images/products/sports-2.jpg', 50, 'Trekking & Running Shoes - black from the Anon eCommerce catalog.', 4.0), ("Men's Leather Formal Wear shoes", 'formal', 50.0, 57.5, './assets/images/products/shoe-1.jpg', 50, "Men's Leather Formal Wear shoes from the Anon eCommerce catalog.", 4.0), ('Better Basics French Terry Sweatshorts', 'shorts', 78.0, 89.7, './assets/images/products/shorts-1.jpg', 50, 'Better Basics French Terry Sweatshorts from the Anon eCommerce catalog.', 4.0)]

init_db()
seed_products()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
